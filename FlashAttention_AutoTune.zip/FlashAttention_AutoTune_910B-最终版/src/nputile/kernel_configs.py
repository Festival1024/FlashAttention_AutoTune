"""内核配置空间与特征提取。

本模块把真实 TileLang FlashAttention 内核的可调参数编码为可枚举、
可预测、可实测筛选的设计空间。FlashAttention 部分对应结题内容:
  * 面向国产芯片架构的算子融合方法 -> TileLang FA 内核实现
  * 基于算子整体框架和具体优化策略的 FlashAttention 设计空间构建方法
    -> block_M/block_N/num_stages 等参数的合法组合及其片上资源约束
  * 基于性能预估与 top-k 实测复筛的 FlashAttention 算子调优方法
    -> config_to_features + NPUPerformanceModel + accept-k 实测

GEMM: /root/ascend_practise/gemm_test/example_gemm_intrinsic.py (910 六字段)
  可调: block_M, block_N, block_K, K_L1, S1, S2
  约束: K_L1 % block_K == 0; L1/L0A/L0B/L0C 容量; 输出 tile 轮询调度到 32 核
GEMM (950PR): /root/ascend_practise-950/gemm_test/example_gemm_ascend950.py
  可调: block_m, block_n, block_k, num_stages (单层流水, 映射见
  gemm950_config_to_features)
FA:   /root/tilelang-ascend/examples/flash_attention/flash_attn_bhsd.py
  可调: block_M, block_N (dim 由模型形状定); 每 V 核处理 block_M/2 行
"""
import itertools

from .kernel_features import NPUKernelFeatures, NPUKernelType


# DS-V4 FA 内核 (src/kernels/flash_attn_tilelang_ds_v4.py) 的实际片上预算
FA_DSV4_L0_MAX_SIZE = 64 * 1024
FA_DSV4_L1_BUDGET = 512 * 1024
FA_DSV4_L0C_BUDGET = 256 * 1024
FA_DSV4_UB_BUDGET = 256 * 1024
FA_DSV4_BLOCK_M_VALUES = (64, 128, 256)
FA_DSV4_BLOCK_N_VALUES = (64, 128, 256)
FA_DSV4_NUM_STAGES_VALUES = (0, 1, 2)


def gemm_config_space(arch, M=1024, N=1024, K=1024, mode="paper"):
    """mode=paper: 论文用子空间 (~54 配置), 真机扫描约 54 x len(M) 次编译;
    mode=full: 全空间 294 配置 (含 S1/S2 单缓冲与 K_L1 4x)"""
    if mode == "paper":
        combos = itertools.product([64, 128, 256], [64, 128, 256],
                                   [32, 64, 128], [1, 2], [2], [2])
    else:
        combos = itertools.product([64, 128, 256], [64, 128, 256],
                                   [32, 64, 128], [1, 2, 4], [1, 2], [1, 2])
    space = []
    for bm, bn, bk, r, s1, s2 in combos:
        k = NPUKernelFeatures(M=M, N=N, K=K, block_M=bm, block_N=bn,
                              block_K=bk, K_L1=bk * r, S1=s1, S2=s2)
        if k.fits_onchip(arch):
            space.append(dict(block_M=bm, block_N=bn, block_K=bk,
                              K_L1=bk * r, S1=s1, S2=s2))
    return space


def fa_ub_usage_bytes(block_M, block_N, dim):
    """与 examples/kernels/flash_attn_bhsd_tunable.py 的 UB 布局一致"""
    rows = block_M // 2
    off = 0
    for nbytes in [rows * dim * 4, rows * 4, rows * 4, rows * block_N * 4,
                   rows * 4, rows * block_N * 4, rows * 4,
                   rows * block_N * 2, rows * dim * 4, rows * dim * 2]:
        off = (off + nbytes + 127) // 128 * 128
    return off


def fa_config_space(arch, dim=128):
    space = []
    for bm, bn in itertools.product([32, 64, 128, 256], [32, 64, 128, 256]):
        k = NPUKernelFeatures(M=1024, N=1024, K=dim, block_M=bm, block_N=bn,
                              block_K=dim, K_L1=dim, S1=2, S2=2,
                              kernel_type=NPUKernelType.FA)
        if (k.fits_onchip(arch) and bm % 2 == 0
                and fa_ub_usage_bytes(bm, bn, dim) <= arch.ub_per_core):
            space.append(dict(block_M=bm, block_N=bn, block_K=dim, K_L1=dim,
                              S1=2, S2=2))
    return space


def fa_dsv4_config_is_valid(block_m: int, block_n: int, num_stages: int,
                            dim: int):
    """按 flash_attn_tilelang_ds_v4.py 的真实缓冲布局做资源约束过滤。

    与 probe_fa.py 的 config_is_valid 保持同一套公式:
      * L0A/L0B 单块最大 64KB, 通过 n_num 拆分 K/V
      * L1 512KB, L0C 256KB, UB 256KB
      * block_M 必须为偶数 (kernel 将 block_M//2 行交给 Vector)
    """
    if block_m <= 0 or block_n <= 0:
        return False, "non-positive tile size"
    if num_stages < 0:
        return False, "negative num_stages"
    if block_m % 2 != 0:
        return False, f"block_M={block_m} must be even (kernel uses block_M//2)"

    n_num = max((block_n * dim * 2 + FA_DSV4_L0_MAX_SIZE - 1)
                // FA_DSV4_L0_MAX_SIZE, 1)
    block_k = (block_n + n_num - 1) // n_num
    block_d = (dim + n_num - 1) // n_num

    l1_bytes = (block_m * dim + block_k * dim + block_n * block_d
                + block_m * block_n) * 2
    l0c_bytes = block_m * (block_k + block_d) * 4

    rows = block_m // 2
    ub_bytes = (2 * (rows * dim * 4)
                + rows * dim * 2
                + 3 * (rows * block_n * 4)
                + rows * block_n * 2
                + 5 * (rows * 4))

    if l1_bytes > FA_DSV4_L1_BUDGET:
        return False, f"L1 {l1_bytes}B > {FA_DSV4_L1_BUDGET}B"
    if l0c_bytes > FA_DSV4_L0C_BUDGET:
        return False, f"L0C {l0c_bytes}B > {FA_DSV4_L0C_BUDGET}B"
    if ub_bytes > FA_DSV4_UB_BUDGET:
        return False, f"UB {ub_bytes}B > {FA_DSV4_UB_BUDGET}B"
    return True, "ok"


def fa_dsv4_config_space(arch=None, dim=512,
                         block_m_values=FA_DSV4_BLOCK_M_VALUES,
                         block_n_values=FA_DSV4_BLOCK_N_VALUES,
                         num_stages_values=FA_DSV4_NUM_STAGES_VALUES):
    """构建 flash_attn_tilelang_ds_v4 的合法配置空间。

    D=512 时 block_M>=128 的 acc_o 累加器 [block_M, dim] fp32 会超过
    L0C/UB 预算, 因此合法空间为 block_M=64 x block_N={64,128}
    x num_stages={0,1,2}, 共 6 个配置。num_stages 对应内核
    T.Pipelined 深度。

    arch 参数保留以兼容统一接口; 本设计空间使用内核实际的 512KB L1 /
    256KB L0C / 256KB UB 硬约束, 不依赖 arch 中的 L0A/L0B 近似模型。
    """
    space = []
    for block_m in block_m_values:
        for block_n in block_n_values:
            for num_stages in num_stages_values:
                ok, _reason = fa_dsv4_config_is_valid(
                    block_m, block_n, num_stages, dim)
                if not ok:
                    continue
                space.append({
                    "block_M": block_m,
                    "block_N": block_n,
                    "block_K": dim,
                    "K_L1": dim,
                    "S1": 2,
                    "S2": 2,
                    "fa_num_stages": num_stages,
                })
    return space


def gemm950_config_to_features(cfg, M, N, K) -> NPUKernelFeatures:
    """昇腾 950PR 内核 (example_gemm_ascend950.py) 配置 -> 特征。

    950 官方 ascend 方言内核是单层流水: T.Pipelined(num_stages) 包裹
    T.copy->L1 (MTE2) 与 T.gemm (内含 MTE1 L1->L0 + Cube), 无 910 内核的
    K_L1/S1/S2 两级流水拆分。映射到四层模型:
      K_L1 = block_K  (loop_kk = 1, 每个 block_K 即一个 L1 stage)
      S1   = num_stages (L1/MTE2 预取流水深度)
      S2   = 2          (T.gemm 硬件内部管理 L0 双缓冲, MTE1 与 Cube 取 max)
    """
    block_k = cfg["block_k"]
    return NPUKernelFeatures(M=M, N=N, K=K,
                             block_M=cfg["block_m"], block_N=cfg["block_n"],
                             block_K=block_k, K_L1=block_k,
                             S1=cfg["num_stages"], S2=2)


def config_to_features(cfg, M, N, K, kernel_type=NPUKernelType.GEMM,
                       heads=1, batch=1) -> NPUKernelFeatures:
    """内核配置 -> 特征 (轮询调度: 输出 tile 按 cid 串行分配到各核)

    支持两种 schema: 910 六字段 (block_M/block_N/block_K/K_L1/S1/S2)
    与 950 四字段 (block_m/block_n/block_k/num_stages)。"""
    if kernel_type == NPUKernelType.GEMM and "num_stages" in cfg:
        return gemm950_config_to_features(cfg, M, N, K)
    return NPUKernelFeatures(M=M, N=N, K=K, kernel_type=kernel_type,
                             heads=heads, batch=batch, **cfg)
