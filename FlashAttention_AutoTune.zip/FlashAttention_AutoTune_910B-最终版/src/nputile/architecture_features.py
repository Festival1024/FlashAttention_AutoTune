"""昇腾 NPU 架构特征定义。

与 GPU (protile) 的对应关系:
  SM           -> AI Core (达芬奇核心)
  HBM          -> HBM (片外显存)
  L2           -> L2 Cache (全核共享)
  smem         -> L1 Buffer (每核 1MB)
  regs         -> L0A/L0B/L0C (每核 64KB/64KB/256KB)
  (NPU 特有)   -> UB (Unified Buffer, 每核 256KB, 供 Vector 单元)
  Tensor Core  -> Cube 单元 (16x16x16 MAC/cycle)
  CUDA Core    -> Vector 单元

数据通路 (搬运引擎):
  MTE2: HBM/L2 -> L1   (含 ND->Nz 格式转换)
  MTE1: L1 -> L0A/L0B
  Cube: L0A x L0B -> L0C
  Fixpipe/MTE3: L0C -> HBM (GEMM 写回)
  FA 额外路径: L0C -> L2/HBM -> UB (Vector/softmax) -> L2/HBM -> L1 (P@V)

架构细节 (910B, 24 达芬奇核, 每核 1 Cube + 2 Vector):
  * L0C 与 UB 之间、L1 与 UB 之间均无直接数据通路;
    L0C 的矩阵结果若要继续做非矩阵计算 (如 FA 的 softmax),
    必须先写回 L2/HBM 再读入 UB 才能交给 Vector 核 (gemm 内核
    的 L0C 结果直接 Fixpipe 写回 HBM, 不受此约束)。
  * workspace (S/P/O 中间结果) 因此产生 2 倍 HBM/L2 往返流量,
    是 FA 类内核的主要带宽开销。
"""
from dataclasses import dataclass


@dataclass
class NPUArchitectureFeatures:
    """昇腾 NPU 架构特征 (单位: 容量 Byte, 带宽 GB/s, 算力 TFLOPS)"""

    # ===== 核心配置 =====
    ai_core_count: int                 # AI Core 数量
    cube_mma_m: int = 16               # Cube 单拍 MAC 阵列 M
    cube_mma_n: int = 16               # Cube 单拍 MAC 阵列 N
    cube_mma_k: int = 16               # Cube 单拍 MAC 阵列 K

    # ===== 存储层次 (Byte) =====
    hbm_size: int = 64 * 1024**3
    l2_cache_size: int = 96 * 1024**2
    l1_per_core: int = 1 * 1024**2
    ub_per_core: int = 256 * 1024
    l0a_per_core: int = 64 * 1024
    l0b_per_core: int = 64 * 1024
    l0c_per_core: int = 256 * 1024

    # ===== 访存带宽 (GB/s, 全芯片总量) =====
    hbm_to_l1_bw: float = 1.2 * 1024        # HBM->L1 (MTE2), ~1.2TB/s
    l2_to_l1_bw: float = 4096.0             # L2->L1
    l2_to_ub_bw: float = 4096.0             # L2->UB (L0C 结果经 L2 写回再读入 UB)
    l1_to_l0_bw: float = 512.0 * 32         # L1->L0 (MTE1), 512B/cycle
    l0c_to_ub_bw: float = 256.0 * 32        # L0C->UB (910 无此直连通路, 仅保留兼容)
    ub_to_l1_bw: float = 256.0 * 32         # UB->L1
    ub_to_vector_bw: float = 256.0 * 32     # UB->Vector 读取
    l0c_to_hbm_bw: float = 1.2 * 1024       # L0C->HBM 写回 (Fixpipe/MTE3)
    vector_to_hbm_bw: float = 1.2 * 1024    # Vector->HBM

    # ===== 计算能力 (TFLOPS) =====
    cube_fp16_tflops: float = 256.0         # Cube FP16
    cube_int8_tops: float = 512.0           # Cube INT8
    vector_fp16_tflops: float = 8.0         # Vector FP16

    # ===== CV 配比 =====
    vec_cores_per_cube: int = 2             # 每 AI(Cube) 核对应的 Vector 核数 (A2: 1C+2V)

    # ===== 微架构常数 =====
    cube_block_latency_cycles: int = 4      # Cube 单条 MMA 流水填充延迟 L_block
    format_convert_ratio: float = 0.05      # ND<->Nz 转换附加开销 (按字节比例)

    # ===== 可校准常数 (由真机数据最小二乘标定, 见 examples/calibrate.py) =====
    mte2_startup_ns: float = 1000.0         # 每次 HBM->L1 DMA 的启动开销 (描述符/同步)
    mte1_startup_ns: float = 100.0          # 每次 L1->L0 DMA 的启动开销
    # 双缓冲稳态下仍暴露在吞吐路径上的启动开销比例 (1=完全暴露, 0=完全被掩盖)
    mte2_startup_exposed_frac: float = 1.0
    mte1_startup_exposed_frac: float = 1.0
    kernel_overhead_ns: float = 0.0         # 每次内核启动的固定开销 (launch/初始化/收尾)
    small_work_overhead_ns: float = 0.0     # 小工作量额外开销 (短内核 DVFS 低时钟段,
                                            #   随波次指数衰减: extra*exp(-(waves-1)/2))
    cube_eff_scale: float = 1.0             # Cube 时延乘子 (有效利用率 <100% 的修正)
    mte2_bw_scale: float = 1.0              # MTE2 有效带宽乘子 (HBM/L2->L1)
    fix_bw_scale: float = 1.0               # L0C->HBM 写回有效带宽乘子
    # 单次 L1 DMA 粒度阈值 (Byte): 传输小于该值时有效带宽按比例折减
    # (真机显示 K_L1=64 的小块传输趋近 HBM 带宽, L2 命中变差); 0 表示不启用
    mte2_granularity_thresh_bytes: float = 0.0
    # 单核 MTE2 端口上限 (bytes/ns): 活跃核少时每核可分得超过 总量/32 的带宽,
    # 但受端口物理上限约束; 0 表示不设上限 (退化为 总量/活跃核数)
    mte2_port_cap_bytes_per_ns: float = 0.0

    def __post_init__(self):
        # GB/s -> bytes/ns
        self.hbm_to_l1_bytes_per_ns = self.hbm_to_l1_bw
        self.l2_to_l1_bytes_per_ns = self.l2_to_l1_bw
        self.l2_to_ub_bytes_per_ns = self.l2_to_ub_bw
        self.l1_to_l0_bytes_per_ns = self.l1_to_l0_bw
        self.l0c_to_ub_bytes_per_ns = self.l0c_to_ub_bw
        self.ub_to_l1_bytes_per_ns = self.ub_to_l1_bw
        self.ub_to_vector_bytes_per_ns = self.ub_to_vector_bw
        self.l0c_to_hbm_bytes_per_ns = self.l0c_to_hbm_bw
        self.vector_to_hbm_bytes_per_ns = self.vector_to_hbm_bw

        # TFLOPS -> ops/ns (全芯片), MAC 记 2 ops
        self.cube_fp16_ops_per_ns = self.cube_fp16_tflops * 1e3
        self.vector_fp16_ops_per_ns = self.vector_fp16_tflops * 1e3

        # Cube 单拍 MAC 数 -> 推出时钟 (cycles/ns)
        # 每核每拍 MAC = 16^3 = 4096; 每核算力 = cube_tflops / ai_core_count (910: 256T/32,
        # 910B: 192T/24, 均为 8 TFLOPS = 4000 MAC/ns)
        macs_per_cycle = self.cube_mma_m * self.cube_mma_n * self.cube_mma_k
        macs_per_core_per_ns = self.cube_fp16_ops_per_ns / self.ai_core_count / 2.0
        self.clock_cycles_per_ns = macs_per_core_per_ns / macs_per_cycle
        # 单条 MMA 指令的发射间隔 I_block (cycles): 一个 16x16x16 tile 占一拍
        self.cube_issue_interval_cycles = 1
