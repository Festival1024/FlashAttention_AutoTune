"""昇腾 910 NPU 四层性能模型 (从 protile GPU 模型适应性迁移)。

层次结构 (与 GPU 四层对应, 见 性能模型构建核心参考信息.md 第3点):
  第一层 (指令层): 每条指令/每条数据通路的时延
      T_MTE2 : HBM->L1  (含 L2 局部性与 ND->Nz 格式转换)
      T_MTE1 : L1->L0
      T_Cube : L_block + I_block * (baseM*baseN*baseK/16^3 - 1)
      T_Fix  : L0C->HBM 写回 (GEMM 末尾一次)
      FA 额外: T_L0C2UB / T_Vector / T_UB2L1 (online softmax 路径)
  第二层 (stage 层): II = max(各通路时延), 判断重叠瓶颈
  第三层 (wave 层): T_tile = 流水填充 + II * (stages-1) + 写回
  第四层 (多核层): T = ceil(tiles / ai_core_count) * T_tile + 预热

硬件效率修正 (参考信息第4点, 与 GPU 的 sm_efficiency 思想一致):
  数据局部性修正存储通路有效带宽; 分块大小对 Cube 的压力修正计算时延。
"""
import math
from dataclasses import dataclass, field

from .architecture_features import NPUArchitectureFeatures
from .kernel_features import NPUKernelFeatures, NPUKernelType


@dataclass
class NPUStageLatency:
    """第一层: 单 stage 各通路时延 (ns)"""
    mte2: float = 0.0      # HBM->L1 (按单个 L0 stage 折算)
    mte1: float = 0.0      # L1->L0
    cube: float = 0.0
    l0c2ub: float = 0.0    # FA: L0C->UB
    vector: float = 0.0    # FA: Vector softmax
    ub2l1: float = 0.0     # FA: UB->L1

    def issue_interval(self) -> float:
        """第二层: 流水线发射间隔 = 各通路最大值"""
        return max(self.mte2, self.mte1, self.cube,
                   self.l0c2ub + self.vector + self.ub2l1)

    def bottleneck(self) -> str:
        names = {"mte2": self.mte2, "mte1": self.mte1, "cube": self.cube,
                 "vector_path": self.l0c2ub + self.vector + self.ub2l1}
        return max(names, key=names.get)


@dataclass
class NPUPrediction:
    total_latency_ns: float
    tile_latency_ns: float
    issue_interval_ns: float
    bottleneck: str
    waves: int
    stage: NPUStageLatency = None


class NPUPerformanceModel:
    def __init__(self, arch: NPUArchitectureFeatures):
        self.arch = arch

    # ================= 第一层: 指令级时延 =================

    def _active_cores(self, k: NPUKernelFeatures) -> int:
        """参与计算的核数: 输出 tile 轮询调度, tile 不足 32 时部分核空闲"""
        return max(1, min(k.total_tiles, self.arch.ai_core_count))

    def _t_mte2_per_l1_stage(self, k: NPUKernelFeatures) -> float:
        """HBM->L1: 一个 L1 级 K 分块 (A 块 + B 块) 的搬运时延"""
        es = k.precision_bits // 8
        if k.kernel_type == NPUKernelType.FA:
            # Q(仅首块) + K/V; 近似按 K/V 两块
            bytes_l1 = 2 * k.block_N * k.K_L1 * es
        else:
            bytes_l1 = (k.block_M + k.block_N) * k.K_L1 * es

        # 数据局部性修正: L2 命中部分走 L2 带宽, 未命中走 HBM 带宽
        # 带宽按活跃核数均分, 且不超过单核 MTE2 端口物理上限
        active = self._active_cores(k)
        hit = k.l2_hit_rate()
        bw_l2 = self.arch.l2_to_l1_bytes_per_ns / active
        bw_hbm = self.arch.hbm_to_l1_bytes_per_ns / active
        cap = self.arch.mte2_port_cap_bytes_per_ns
        if cap > 0:
            bw_l2 = min(bw_l2, cap)
            bw_hbm = min(bw_hbm, cap)
        bw_l2 *= self.arch.mte2_bw_scale
        bw_hbm *= self.arch.mte2_bw_scale
        # 小粒度 DMA 有效带宽折减: bytes_l1 低于阈值时按比例降带宽
        thresh = self.arch.mte2_granularity_thresh_bytes
        if thresh > 0 and bytes_l1 < thresh:
            bw_l2 *= bytes_l1 / thresh
            bw_hbm *= bytes_l1 / thresh
        t = bytes_l1 * hit / bw_l2 + bytes_l1 * (1 - hit) / bw_hbm
        # ND->Nz 格式转换开销
        t *= (1 + self.arch.format_convert_ratio)
        return t + self.arch.mte2_startup_ns

    def _t_mte1_per_l0_stage(self, k: NPUKernelFeatures) -> float:
        es = k.precision_bits // 8
        if k.kernel_type == NPUKernelType.FA:
            bytes_l0 = 2 * k.block_N * k.block_K * es
        else:
            bytes_l0 = (k.block_M + k.block_N) * k.block_K * es
        return bytes_l0 / self.arch.l1_to_l0_bytes_per_ns * (1 + self.arch.format_convert_ratio) \
            + self.arch.mte1_startup_ns

    def _t_cube_per_l0_stage(self, k: NPUKernelFeatures) -> float:
        """Cube: L_block + I_block * (baseM*baseN*baseK/16^3 - 1)"""
        macs = k.block_M * k.block_N * k.block_K
        if k.kernel_type == NPUKernelType.FA:
            macs *= 2  # QK^T + PV 两个 GEMM
        mma_macs = self.arch.cube_mma_m * self.arch.cube_mma_n * self.arch.cube_mma_k
        cycles = self.arch.cube_block_latency_cycles + \
            self.arch.cube_issue_interval_cycles * max(0, macs / mma_macs - 1)
        t = cycles / self.arch.clock_cycles_per_ns
        # 分块压力修正: 小 tile 的 Cube 阵列利用率低且指令调度开销占比升高
        t /= self._cube_efficiency(k)
        # 有效利用率全局修正 (校准常数)
        t *= self.arch.cube_eff_scale
        return t

    def _cube_efficiency(self, k: NPUKernelFeatures) -> float:
        """Cube 单元效率: tile 越小, 16x16x16 阵列填充率越低、发射开销越大"""
        eff = 1.0
        # M/N 维对 16 的填充率
        eff *= min(1.0, k.block_M / self.arch.cube_mma_m) * min(1.0, k.block_N / self.arch.cube_mma_n) \
            if k.block_M < 16 or k.block_N < 16 else 1.0
        # 过小输出 tile: 指令调度/同步开销
        if k.block_M * k.block_N <= 64 * 64:
            eff *= 0.8
        return eff

    def _t_fix_per_tile(self, k: NPUKernelFeatures) -> float:
        es = k.accum_bits // 8
        if k.kernel_type == NPUKernelType.FA:
            bytes_wb = k.block_M * k.K_L1 * es  # O: block_M x dim
        else:
            bytes_wb = k.block_M * k.block_N * es
        t = bytes_wb / (self.arch.l0c_to_hbm_bytes_per_ns / self._active_cores(k))
        return t * (1 + self.arch.format_convert_ratio) * self.arch.fix_bw_scale

    # ---------- FA (flash_attn_tilelang_ds_v4) 跨单元 CV 流水 ----------
    # 内核结构: 每 (Q块, head) 一个 tile; 每达芬奇核内 1 Cube + 2 Vector 单元,
    # 各 Vector 单元处理 block_M/2 行; S/P/O 中间结果因 L0C<->UB / L1<->UB 无
    # 直连通路, 必须经 HBM workspace 往返 (L0C->ws->UB / UB->ws->L1);
    # KV 循环由 T.Pipelined(num_stages) 预取流水 (真机: 0/1 等价, >=2 才重叠)。
    def _fa_ws_bytes(self, k: NPUKernelFeatures) -> dict:
        """每 KV 迭代的 workspace 字节数 (S/P/O 经 L2/HBM 往返)"""
        bmn = k.block_M * k.block_N
        dim = k.K_L1
        return {
            "ws1_wb": bmn * 4,          # L0C->HBM (S fp32)
            "ws1_rd": bmn * 4,          # HBM/L2->UB
            "ws2_wb": bmn * 2,          # UB->HBM (P fp16)
            "ws2_rd": bmn * 2,          # HBM/L2->L1
            "ws3_wb": k.block_M * dim * 4,   # L0C->HBM (O fp32)
            "ws3_rd": k.block_M * dim * 4,   # HBM/L2->UB
        }

    def _fa_engine_latencies(self, k: NPUKernelFeatures):
        """每 KV 迭代四路引擎时延 (ns/tile): cube / vector / mte2 / 写回"""
        es = k.precision_bits // 8
        dim = k.K_L1
        ncore = self.arch.ai_core_count
        ws = self._fa_ws_bytes(k)
        hit = k.l2_hit_rate()

        # Cube: QK^T + PV 两个 GEMM
        macs = k.block_M * k.block_N * dim
        t_cube = 2 * (self.arch.cube_block_latency_cycles +
                      max(0, macs / 4096 - 1)) / self.arch.clock_cycles_per_ns \
            / self._cube_efficiency(k) * self.arch.cube_eff_scale

        # Vector: 每 V 核 block_M/2 行; ~7 ops/S 元素 + ~3 ops/O 元素
        rows = k.block_M // 2
        vec_ops_pc = self.arch.vector_fp16_ops_per_ns / ncore
        t_vec = (7 * rows * k.block_N + 3 * rows * dim) / vec_ops_pc

        # MTE2: K/V 载入 L1 (流式, 命中率修正) + ws 读回 (走 L2)
        kv_bytes = 2 * k.block_N * dim * es
        ws_read = ws["ws1_rd"] + ws["ws2_rd"] + ws["ws3_rd"]
        cap = self.arch.mte2_port_cap_bytes_per_ns
        bw_hbm_pc = self.arch.hbm_to_l1_bytes_per_ns / ncore * self.arch.mte2_bw_scale
        bw_l2_pc = self.arch.l2_to_l1_bytes_per_ns / ncore * self.arch.mte2_bw_scale
        bw_l2ub_pc = self.arch.l2_to_ub_bytes_per_ns / ncore * self.arch.mte2_bw_scale
        if cap > 0:
            bw_hbm_pc = min(bw_hbm_pc, cap)
            bw_l2_pc = min(bw_l2_pc, cap)
            bw_l2ub_pc = min(bw_l2ub_pc, cap)
        t_mte2 = (kv_bytes * (1 - hit) / bw_hbm_pc
                  + kv_bytes * hit / bw_l2_pc
                  + (ws["ws1_rd"] + ws["ws3_rd"]) / bw_l2ub_pc
                  + ws["ws2_rd"] / bw_l2_pc
                  + self.arch.mte2_startup_ns)

        # 写回: L0C->HBM (Fixpipe, ws1+ws3) + UB->HBM (ws2)
        bw_fix_pc = self.arch.l0c_to_hbm_bytes_per_ns / ncore
        bw_vhbm_pc = self.arch.vector_to_hbm_bytes_per_ns / ncore
        t_wb = (ws["ws1_wb"] + ws["ws3_wb"]) / bw_fix_pc \
            * (1 + self.arch.format_convert_ratio) * self.arch.fix_bw_scale \
            + ws["ws2_wb"] / bw_vhbm_pc
        return t_cube, t_vec, t_mte2, t_wb

    def _predict_fa_cross_core(self, k: NPUKernelFeatures) -> NPUPrediction:
        """flash_attn_tilelang_ds_v4: Cube/Vector 经 HBM workspace 流水握手,
        每迭代内各引擎时延合成; num_stages>=2 时各引擎跨迭代重叠 (II=max),
        0/1 时全串行 (真机 0 与 1 时延等价)。"""
        n_kv = k.total_l0_stages()  # seq_len / block_N
        es = k.precision_bits // 8
        dim = k.K_L1
        ncore = self.arch.ai_core_count
        t_cube, t_vec, t_mte2, t_wb = self._fa_engine_latencies(k)

        # 首迭代: Q 载入 + 首 S 产出 (Cube1 + ws1 写回) 才轮到 Vector
        bw_hbm_pc = self.arch.hbm_to_l1_bytes_per_ns / ncore
        t_q = k.block_M * dim * es / bw_hbm_pc + self.arch.mte2_startup_ns
        fill = t_q + t_cube / 2 + (k.block_M * k.block_N * 4) / \
            (self.arch.l0c_to_hbm_bytes_per_ns / ncore) * self.arch.fix_bw_scale
        # 收尾: 末迭代 Vector 侧除法 + O 写回 HBM
        rows = k.block_M // 2
        vec_ops_pc = self.arch.vector_fp16_ops_per_ns / ncore
        t_drain = rows * dim / vec_ops_pc + k.block_M * dim * es / bw_hbm_pc

        if k.fa_num_stages >= 2:
            ii = max(t_cube, t_vec, t_mte2, t_wb)
        else:
            ii = t_cube + t_vec + t_mte2 + t_wb
        t_tile = fill + ii * (n_kv - 1) + t_drain

        waves = math.ceil(k.total_tiles / ncore)
        overhead = self.arch.kernel_overhead_ns + \
            self.arch.small_work_overhead_ns * math.exp(-(waves - 1) / 2.0)
        # 同核相邻 tile: 首个 tile 付完整时延, 后续 tile 的 K/V 预取与前一
        # tile 收尾重叠, 付 II*(n_kv-1) + max(fill, drain) 的边际时延
        t_marginal = ii * (n_kv - 1) + max(fill, t_drain)
        total = t_tile + (waves - 1) * t_marginal + overhead

        stage = NPUStageLatency(mte2=t_mte2, cube=t_cube, vector=t_vec,
                                ub2l1=t_wb)
        names = {"cube": t_cube, "vector": t_vec, "mte2": t_mte2, "wb": t_wb}
        return NPUPrediction(
            total_latency_ns=total,
            tile_latency_ns=t_tile,
            issue_interval_ns=ii,
            bottleneck=max(names, key=names.get),
            waves=waves,
            stage=stage,
        )

    def predict_latency(self, k: NPUKernelFeatures) -> NPUPrediction:
        if k.kernel_type == NPUKernelType.FA and k.fa_cross_core:
            return self._predict_fa_cross_core(k)

        loop_k = k.loop_k()
        loop_kk = k.loop_kk()
        stages = k.total_l0_stages()

        t_mte2 = self._t_mte2_per_l1_stage(k)      # 每 L1 stage (含启动开销)
        t_mte1 = self._t_mte1_per_l0_stage(k)      # 每 L0 stage (含启动开销)
        e2 = self._t_cube_per_l0_stage(k)
        t_fix = self._t_fix_per_tile(k)

        # DMA 启动开销与传输分离: 双缓冲稳态下描述符/同步开销可部分被前一次
        # 传输掩盖, 暴露比例由校准决定 (真机显示 MTE2 启动基本完全暴露,
        # 这是 K_L1 大分块优势的主要来源); 单缓冲时每次 DMA 的启动都串行暴露。
        t_mte2_xfer = t_mte2 - self.arch.mte2_startup_ns
        t_mte1_xfer = t_mte1 - self.arch.mte1_startup_ns
        t_mte2_steady = t_mte2_xfer + \
            self.arch.mte2_startup_ns * self.arch.mte2_startup_exposed_frac
        t_mte1_steady = t_mte1_xfer + \
            self.arch.mte1_startup_ns * self.arch.mte1_startup_exposed_frac

        # 第二层 (stage 层): 分级流水重叠 (对照内核 set_flag/wait_flag 语义)
        #   S2>=2: MTE1 与 Cube 双缓冲重叠 -> 内层 II = max(e1, e2)
        #   S2==1: L0 单缓冲, MTE1 必须等上一拍 Cube 完成 -> 内层串行 e1+e2
        #   S1>=2: MTE2 预取下一块 L1, 与内层流水重叠 -> II = max(e0, inner)
        #   S1==1: L1 单缓冲, MTE2 排在内层流水之外串行, 每个 L1 stage 流水排空
        if k.is_l0_pipelined():
            inner = max(t_mte1_steady, e2)
            inner_fill = t_mte1 + e2
        else:
            inner = t_mte1 + e2
            inner_fill = inner
        if k.is_l1_pipelined():
            e0 = t_mte2_steady / loop_kk
            ii = max(e0, inner)
            # 第三层 (wave 层): 流水填充 + II * (stages-1) + 末尾写回
            fill = t_mte2 + inner_fill
            t_tile = fill + ii * (stages - 1) + t_fix
            # 同核相邻 tile 间: 前一 tile 收尾 (末拍 Cube + L0C 写回) 与后一 tile
            # 填充 (首个 MTE2/MTE1 预取) 分属不同引擎, 相互重叠
            t_drain = e2 + t_fix
            t_marginal = ii * (stages - 1) + max(t_drain, fill)
        else:
            per_l1 = t_mte2 + t_mte1 + inner * max(0, loop_kk - 1)
            t_tile = loop_k * per_l1 + e2 + t_fix
            ii = (t_mte2 + inner * loop_kk) / loop_kk
            e0 = t_mte2 / loop_kk
            # 单缓冲流水每 L1 stage 已排空, 仅写回可与下一 tile 的首次 MTE2 重叠
            t_marginal = t_tile - min(t_fix, t_mte2)

        stage = NPUStageLatency(mte2=e0, mte1=t_mte1, cube=e2)

        # 第四层 (多核层): 临界核承担 ceil(tiles/核数) 个 tile;
        # 首个 tile 付完整时延, 后续 tile 付边际时延;
        # 固定开销 + 小工作量额外开销 (短内核低速时钟段, 随波次衰减)
        waves = math.ceil(k.total_tiles / self.arch.ai_core_count)
        overhead = self.arch.kernel_overhead_ns + \
            self.arch.small_work_overhead_ns * math.exp(-(waves - 1) / 2.0)
        total = t_tile + (waves - 1) * t_marginal + overhead

        return NPUPrediction(
            total_latency_ns=total,
            tile_latency_ns=t_tile,
            issue_interval_ns=ii,
            bottleneck=stage.bottleneck(),
            waves=waves,
            stage=stage,
        )
