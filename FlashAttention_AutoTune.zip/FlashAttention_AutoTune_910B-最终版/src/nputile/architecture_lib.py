"""预置架构库。"""
from .architecture_features import NPUArchitectureFeatures


def create_ascend_910_architecture() -> NPUArchitectureFeatures:
    """昇腾 910 (达芬奇架构, 32 AI Core)。

    参数来源: 性能模型构建核心参考信息.md (用户登记的有效参数),
    以及 Ascend HPCA2020 / DaVinci 架构公开规格。
    """
    return NPUArchitectureFeatures(
        ai_core_count=32,
        hbm_size=64 * 1024**3,
        l2_cache_size=96 * 1024**2,
        l1_per_core=1 * 1024**2,
        ub_per_core=256 * 1024,
        l0a_per_core=64 * 1024,
        l0b_per_core=64 * 1024,
        l0c_per_core=256 * 1024,
        hbm_to_l1_bw=1.2 * 1024,
        l2_to_l1_bw=4096.0,
        l1_to_l0_bw=512.0 * 32,
        l0c_to_ub_bw=256.0 * 32,
        ub_to_l1_bw=256.0 * 32,
        ub_to_vector_bw=256.0 * 32,
        l0c_to_hbm_bw=3350.0,
        cube_fp16_tflops=256.0,
        cube_int8_tops=512.0,
        vector_fp16_tflops=8.0,
    )


def create_ascend_910b_architecture() -> NPUArchitectureFeatures:
    """昇腾 910B (达芬奇架构, 24 达芬奇核, 每核 1 Cube + 2 Vector)。

    2026-10-04 用户勘误后的登记参数:
      * 24 个达芬奇核 (原按 32 核);
      * 每核 L1=1MB, UB=256KB, L0A/L0B=64KB, L0C=256KB;
      * L0C<->UB、L1<->UB 无直连通路, L0C 中间结果须经 L2/HBM 往返;
      * Cube FP16 192 TFLOPS (8T/核), Vector FP16 12 TFLOPS (24 核合计);
      * L0C->HBM 写回 = HBM 带宽 1.2TB/s (原登记 3350 为旧值)。
    """
    return NPUArchitectureFeatures(
        ai_core_count=24,
        hbm_size=64 * 1024**3,
        l2_cache_size=96 * 1024**2,
        l1_per_core=1 * 1024**2,
        ub_per_core=256 * 1024,
        l0a_per_core=64 * 1024,
        l0b_per_core=64 * 1024,
        l0c_per_core=256 * 1024,
        hbm_to_l1_bw=1.2 * 1024,
        l2_to_l1_bw=4096.0,
        l2_to_ub_bw=4096.0,
        l1_to_l0_bw=512.0 * 24,
        l0c_to_ub_bw=256.0 * 24,
        ub_to_l1_bw=256.0 * 24,
        ub_to_vector_bw=256.0 * 24,
        l0c_to_hbm_bw=1.2 * 1024,
        vector_to_hbm_bw=1.2 * 1024,
        cube_fp16_tflops=192.0,
        cube_int8_tops=384.0,
        vector_fp16_tflops=12.0,
    )


def create_ascend_950pr_architecture() -> NPUArchitectureFeatures:
    """昇腾 950PR (达芬奇架构, 32 AI Core)。

    2026-10-05 用户登记参数 (soc 9579, CANN 9.2):
      * 32 个 AI Core; HBM 128GB / 1.6TB/s; L2 128MB;
      * 每核 L1=512KB, UB=512KB, L0A/L0B=64KB, L0C=256KB;
      * L2->L1 / L2->UB 带宽白皮书登记 >=8192 GB/s (效率值按上一代口径登记);
      * L1->L0 带宽未公布, 假设与上一代一致 (512B/cycle/核);
      * 950 的 UB/L0/L1 可直接相互访存 (利好 FA, GEMM 走 Fixpipe 写回不受影响);
      * Cube FP16 432 TFLOPS, Vector FP16 27 TFLOPS; INT8 按 FP16 两倍登记。
    """
    return NPUArchitectureFeatures(
        ai_core_count=32,
        hbm_size=128 * 1024**3,
        l2_cache_size=128 * 1024**2,
        l1_per_core=512 * 1024,
        ub_per_core=512 * 1024,
        l0a_per_core=64 * 1024,
        l0b_per_core=64 * 1024,
        l0c_per_core=256 * 1024,
        hbm_to_l1_bw=1.6 * 1024,
        l2_to_l1_bw=8192.0,
        l2_to_ub_bw=8192.0,
        l1_to_l0_bw=512.0 * 32,
        l0c_to_ub_bw=256.0 * 32,
        ub_to_l1_bw=256.0 * 32,
        ub_to_vector_bw=256.0 * 32,
        l0c_to_hbm_bw=1.6 * 1024,
        vector_to_hbm_bw=1.6 * 1024,
        cube_fp16_tflops=432.0,
        cube_int8_tops=864.0,
        vector_fp16_tflops=27.0,
    )
