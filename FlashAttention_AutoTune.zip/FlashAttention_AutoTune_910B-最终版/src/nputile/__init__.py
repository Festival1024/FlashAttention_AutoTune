"""nputile: 以 tile 为核心的昇腾 910 NPU 内核剖析器 (从 protile/GPU 迁移)。"""
from .architecture_features import NPUArchitectureFeatures
from .architecture_lib import (create_ascend_910_architecture,
                               create_ascend_910b_architecture,
                               create_ascend_950pr_architecture)
from .kernel_features import NPUKernelFeatures, NPUKernelType
from .performance_model import NPUPerformanceModel

__all__ = [
    "NPUArchitectureFeatures",
    "create_ascend_910_architecture",
    "create_ascend_910b_architecture",
    "create_ascend_950pr_architecture",
    "NPUKernelFeatures",
    "NPUKernelType",
    "NPUPerformanceModel",
]
