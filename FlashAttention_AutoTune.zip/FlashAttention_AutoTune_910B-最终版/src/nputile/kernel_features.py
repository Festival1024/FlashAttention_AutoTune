"""NPU 内核特征 (tile 为核心)。

对应 tilelang-ascend gemm-intrinsic 的可调参数:
  block_M, block_N : 输出 tile (每 AI Core 一个, L0C 驻留)
  block_K          : L0 级 K 分块 (L0A/L0B 一次装载的 K 长度)
  K_L1             : L1 级 K 分块 (HBM->L1 一次装载的 K 长度)
  S1               : L1 缓冲级数 (HBM->L1 流水深度, 双缓冲=2)
  S2               : L0 缓冲级数 (L1->L0 流水深度, 双缓冲=2)

对应 flash_attn_bhsd 的可调参数: block_M, block_N (dim 固定),
K/V 按 block_N 分块迭代 (online softmax)。
"""
import math
from dataclasses import dataclass
from enum import Enum
from typing import Tuple


class NPUKernelType(Enum):
    GEMM = "gemm"
    FA = "flash_attention"


@dataclass
class NPUKernelFeatures:
    # 输入形状: GEMM 为 M/N/K; FA 为 seq_len(M=N)/dim*heads(K=dim*heads)
    M: int
    N: int
    K: int

    # 分块参数
    block_M: int
    block_N: int
    block_K: int          # FA 中固定 = dim
    K_L1: int = 0         # L1 级 K 分块; 0 表示 = block_K (单层流水)
    S1: int = 2           # L1 流水级数
    S2: int = 2           # L0 流水级数

    kernel_type: NPUKernelType = NPUKernelType.GEMM
    heads: int = 1          # FA: 注意力头数
    batch: int = 1          # FA: batch
    fa_cross_core: bool = True  # FA: Cube 与 Vector 经 HBM workspace 跨单元流水
    fa_num_stages: int = 1  # FA: KV 循环 T.Pipelined 深度 (flash_attn_tilelang_ds_v4
                            #   的 num_stages; 真机显示 0 与 1 等价, >=2 才重叠)

    precision_bits: int = 16
    accum_bits: int = 32
    trans_A: bool = False
    trans_B: bool = True

    def __post_init__(self):
        if self.K_L1 <= 0:
            self.K_L1 = self.block_K
        # L1 级 K 分块必须是 L0 级分块的整数倍
        if self.K_L1 % self.block_K != 0:
            self.K_L1 = int(math.ceil(self.K_L1 / self.block_K)) * self.block_K
        self.m_num = math.ceil(self.M / self.block_M)
        self.n_num = math.ceil(self.N / self.block_N)
        if self.kernel_type == NPUKernelType.FA:
            # FA: 每核一个 (Q块, head) 对; block_K = K_L1 = dim
            self.total_tiles = self.m_num * self.heads * self.batch
        else:
            self.total_tiles = self.m_num * self.n_num

    # ---------- 流水结构 ----------
    def loop_k(self) -> int:
        """L1 级 K 迭代次数 (每 tile)"""
        return math.ceil(self.K / self.K_L1)

    def loop_kk(self) -> int:
        """每个 L1 分块内的 L0 级迭代次数"""
        return math.ceil(self.K_L1 / self.block_K)

    def total_l0_stages(self) -> int:
        """每 tile 的 L0 级总迭代次数"""
        if self.kernel_type == NPUKernelType.FA:
            # FA: 沿 KV 维按 block_N 迭代 (online softmax)
            return math.ceil(self.N / self.block_N)
        return math.ceil(self.K / self.block_K)

    def is_l1_pipelined(self) -> bool:
        return self.S1 >= 2

    def is_l0_pipelined(self) -> bool:
        return self.S2 >= 2

    # ---------- 资源占用 ----------
    def l1_usage_bytes(self) -> int:
        es = self.precision_bits // 8
        if self.kernel_type == NPUKernelType.FA:
            # Q, K, V 驻留 L1
            return (self.block_M + 2 * self.block_N) * self.K_L1 * es
        return (self.block_M + self.block_N) * self.K_L1 * es * max(1, self.S1)

    def l0_usage_bytes(self) -> int:
        es = self.precision_bits // 8
        a = self.block_M * self.block_K * es * max(1, self.S2)
        b = self.block_N * self.block_K * es * max(1, self.S2)
        return a, b

    def l0c_usage_bytes(self) -> int:
        es = self.accum_bits // 8
        if self.kernel_type == NPUKernelType.FA:
            # S 和 O 两块累加器
            return (self.block_M * self.block_N + self.block_M * self.K_L1) * es
        return self.block_M * self.block_N * es

    def fits_onchip(self, arch) -> bool:
        a, b = self.l0_usage_bytes()
        return (
            self.l1_usage_bytes() <= arch.l1_per_core
            and a <= arch.l0a_per_core
            and b <= arch.l0b_per_core
            and self.l0c_usage_bytes() <= arch.l0c_per_core
        )

    # ---------- 数据局部性 (L2 命中率, 沿用 GPU 模型的思想) ----------
    def l2_hit_rate(self) -> float:
        """L2 命中率: 全核共享 L2, use_swizzle 调度下与分块几何相关"""
        if self.kernel_type == NPUKernelType.FA:
            dim, heads = self.K, self.heads
            total = self.m_num * self.n_num * dim * heads * (self.block_M + 2 * self.block_N)
            un_cache = dim * heads * (self.M + 2 * self.N)
            return max(0.0, 1.0 - un_cache / max(1, total))
        m_num, n_num = self.m_num, self.n_num
        # 总访存块数: 每个输出 tile 读 A 块 + B 块
        total = m_num * n_num * (self.block_M + self.block_N)
        # 不命中(首次加载): A 矩阵 m_num 行块 + B 矩阵 n_num 列块
        un_cache = m_num * self.block_M + n_num * self.block_N
        hit = 1.0 - un_cache / total
        return max(0.0, hit)

    def compute_cube_tile_macs(self) -> int:
        """单条 Cube 流水 (一个 L0 stage) 的 MAC 数"""
        return self.block_M * self.block_N * self.block_K
