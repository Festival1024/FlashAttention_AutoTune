"""flash_attn_bhsd 可调参数版 (vendored & modified)。

来源: /root/tilelang-ascend/examples/flash_attention/flash_attn_bhsd.py
改动: block_M/block_N 由函数参数传入; UB/L1 显式地址按分块大小参数化
     (不重叠布局, 128B 对齐; 原版对 block_M=block_N=64, dim=512 手写地址)。
结构: Cube 核与 Vector 核经 HBM workspace 跨核流水 (cross_flag 握手),
     每个 Vector 核处理 block_M/2 行 (A2: 1 Cube + 2 Vector)。
"""
import tilelang
from tilelang import DataType, language as T


def _align128(x):
    return (x + 127) // 128 * 128


@tilelang.jit(out_idx=[3], workspace_idx=[4, 5, 6])
def flash_attention_fwd(batch, seq_len, heads, dim, block_M, block_N):
    dtype = "float16"
    accum_dtype = "float"

    sm_scale = (1.0 / dim) ** 0.5
    shape = [batch, heads, seq_len, dim]
    block_num = seq_len // block_M * heads * batch
    es = DataType(dtype).bits // 8
    rows = block_M // 2

    # ---- L1 地址 (acc_s_l1 与 k_l1 分时复用, 同原版) ----
    addr_q = 0
    addr_k = _align128(block_M * dim * es)
    addr_s = addr_k
    addr_v = _align128(block_M * (block_N + dim) * es)

    # ---- UB 地址 (不重叠布局, 128B 对齐) ----
    ub = {}
    off = 0
    for name, nbytes in [
        ("acc_o", rows * dim * 4),
        ("sumexp", rows * 4),
        ("m_i", rows * 4),
        ("acc_s_ub", rows * block_N * 4),
        ("m_i_prev", rows * 4),
        ("acc_s_ub_", rows * block_N * 4),
        ("sumexp_i_ub", rows * 4),
        ("acc_s_half", rows * block_N * es),
        ("acc_o_ub", rows * dim * 4),
        ("acc_o_half", rows * dim * es),
    ]:
        ub[name] = off
        off = _align128(off + nbytes)
    ub_total = off

    @T.prim_func
    def main(
            Q: T.Tensor(shape, dtype),       # type: ignore
            K: T.Tensor(shape, dtype),       # type: ignore
            V: T.Tensor(shape, dtype),       # type: ignore
            Output: T.Tensor(shape, dtype),  # type: ignore
            workspace_1: T.Tensor([block_num, block_M, block_N], accum_dtype),   # type: ignore
            workspace_2: T.Tensor([block_num, block_M, block_N], dtype),         # type: ignore
            workspace_3: T.Tensor([block_num, block_M, dim], accum_dtype),       # type: ignore
    ):
        with T.Kernel(block_num, is_npu=True) as (cid, vid):
            bx = cid % (seq_len // block_M)
            by = cid // (seq_len // block_M) % heads
            bz = cid // (seq_len // block_M) // heads % batch

            q_l1 = T.alloc_L1([block_M, dim], dtype)
            k_l1 = T.alloc_L1([block_N, dim], dtype)
            v_l1 = T.alloc_L1([block_N, dim], dtype)

            acc_s_l1 = T.alloc_L1([block_M, block_N], dtype)

            acc_s_l0c = T.alloc_L0C([block_M, block_N], accum_dtype)
            acc_o_l0c = T.alloc_L0C([block_M, dim], accum_dtype)

            acc_o = T.alloc_ub([rows, dim], accum_dtype)
            sumexp = T.alloc_ub([rows], accum_dtype)
            m_i = T.alloc_ub([rows], accum_dtype)

            acc_s_ub = T.alloc_ub([rows, block_N], accum_dtype)
            m_i_prev = T.alloc_ub([rows], accum_dtype)
            acc_s_ub_ = T.alloc_ub([rows, block_N], accum_dtype)
            sumexp_i_ub = T.alloc_ub([rows], accum_dtype)
            acc_s_half = T.alloc_ub([rows, block_N], dtype)
            acc_o_ub = T.alloc_ub([rows, dim], accum_dtype)
            acc_o_half = T.alloc_ub([rows, dim], dtype)

            T.annotate_address({
                q_l1: addr_q,
                k_l1: addr_k,
                acc_s_l1: addr_s,
                v_l1: addr_v,

                acc_s_l0c: 0,
                acc_o_l0c: 0,

                acc_o: ub["acc_o"],
                sumexp: ub["sumexp"],
                m_i: ub["m_i"],
                acc_s_ub: ub["acc_s_ub"],
                m_i_prev: ub["m_i_prev"],
                acc_s_ub_: ub["acc_s_ub_"],
                sumexp_i_ub: ub["sumexp_i_ub"],
                acc_s_half: ub["acc_s_half"],
                acc_o_ub: ub["acc_o_ub"],
                acc_o_half: ub["acc_o_half"],
            })

            with T.Scope("C"):
                T.copy(Q[bz, by, bx * block_M:(bx + 1) * block_M, :], q_l1)
                T.barrier_all()
                for k in T.serial(T.ceildiv(seq_len, block_N)):
                    T.copy(K[bz, by, k * block_N:(k + 1) * block_N, :], k_l1)
                    T.barrier_all()

                    T.gemm_v0(q_l1, k_l1, acc_s_l0c, transpose_B=True, init=True)
                    T.barrier_all()

                    T.copy(acc_s_l0c, workspace_1[cid, :, :])
                    T.barrier_all()
                    T.set_cross_flag("FIX", 0)

                    T.wait_cross_flag(1)
                    T.barrier_all()

                    T.copy(workspace_2[cid, :, :], acc_s_l1)
                    T.copy(V[bz, by, k * block_N:(k + 1) * block_N, :], v_l1)
                    T.barrier_all()

                    T.gemm_v0(acc_s_l1, v_l1, acc_o_l0c, init=True)
                    T.barrier_all()

                    T.copy(acc_o_l0c, workspace_3[cid, :, :])
                    T.barrier_all()

                    T.set_cross_flag("FIX", 2)
                    T.wait_cross_flag(3)

            with T.Scope("V"):

                T.tile.fill(acc_o, 0.0)
                T.tile.fill(sumexp, 0.0)
                T.tile.fill(m_i, -2**30)
                T.barrier_all()

                for _k in T.serial(T.ceildiv(seq_len, block_N)):
                    T.tile.fill(acc_s_ub, 0.0)
                    T.barrier_all()

                    T.copy(m_i, m_i_prev)
                    T.barrier_all()

                    T.wait_cross_flag(0)
                    T.copy(
                        workspace_1[cid, vid * rows:vid * rows + rows, :],
                        acc_s_ub_)
                    T.barrier_all()

                    T.tile.add(acc_s_ub, acc_s_ub, acc_s_ub_)
                    T.barrier_all()

                    T.tile.mul(acc_s_ub, acc_s_ub, sm_scale)
                    T.barrier_all()

                    T.reduce_max(acc_s_ub, m_i, dim=-1)
                    T.barrier_all()

                    T.tile.max(m_i, m_i, m_i_prev)
                    T.barrier_all()

                    T.tile.sub(m_i_prev, m_i_prev, m_i)
                    T.barrier_all()

                    T.tile.exp(m_i_prev, m_i_prev)
                    T.barrier_all()

                    for h_i in range(rows):
                        T.barrier_all()
                        T.tile.sub(acc_s_ub[h_i, :], acc_s_ub[h_i, :], m_i[h_i])
                        T.barrier_all()

                    T.tile.exp(acc_s_ub, acc_s_ub)
                    T.barrier_all()

                    T.reduce_sum(acc_s_ub, sumexp_i_ub, dim=-1)
                    T.barrier_all()

                    T.tile.mul(sumexp, sumexp, m_i_prev)
                    T.barrier_all()

                    T.tile.add(sumexp, sumexp, sumexp_i_ub)
                    T.barrier_all()

                    for h_i in range(rows):
                        T.barrier_all()
                        T.tile.mul(acc_o[h_i, :], acc_o[h_i, :], m_i_prev[h_i])
                        T.barrier_all()

                    T.copy(acc_s_ub, acc_s_half)
                    T.barrier_all()

                    T.copy(
                        acc_s_half,
                        workspace_2[cid, vid * rows:vid * rows + rows, :])
                    T.barrier_all()

                    T.set_cross_flag("MTE3", 1)

                    T.wait_cross_flag(2)
                    T.barrier_all()

                    T.copy(
                        workspace_3[cid, vid * rows:vid * rows + rows, :],
                        acc_o_ub)
                    T.barrier_all()

                    T.tile.add(acc_o, acc_o, acc_o_ub)
                    T.barrier_all()

                    T.set_cross_flag("V", 3)
                    T.barrier_all()

                for h_i in range(rows):
                    T.barrier_all()
                    T.tile.div(acc_o[h_i, :], acc_o[h_i, :], sumexp[h_i])
                    T.barrier_all()

                T.copy(acc_o, acc_o_half)
                T.barrier_all()
                T.copy(
                    acc_o_half, Output[bz, by, bx * block_M + vid * rows:bx * block_M +
                                       vid * rows + rows, :])

    return main


def build_fa(B, S, H, D, cfg):
    return flash_attention_fwd(B, S, H, D, cfg["block_M"], cfg["block_N"])


def ub_usage_bytes(block_M, block_N, dim):
    rows = block_M // 2
    off = 0
    for nbytes in [rows * dim * 4, rows * 4, rows * 4, rows * block_N * 4,
                   rows * 4, rows * block_N * 4, rows * 4,
                   rows * block_N * 2, rows * dim * 4, rows * dim * 2]:
        off = _align128(off + nbytes)
    return off
