#!/usr/bin/env python3
"""性能模型指导的 FA 内核配置预筛。

对应结题内容:
  * 基于算子整体框架和具体优化策略的 FlashAttention 设计空间构建方法
    -> fa_dsv4_config_space
  * 基于性能预估与 top-k 实测复筛的 FlashAttention 算子调优方法
    -> NPUPerformanceModel.predict_latency + top-k 排序

本脚本只做解析预测, 不依赖 NPU 设备, 可在无卡环境运行:
  python3 tools/predict_topk.py --accept-k 3

输出:
  results/predictions/fa_dsv4_topk.json
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from nputile import (NPUPerformanceModel, NPUKernelType,
                     create_ascend_910b_architecture)
from nputile.kernel_configs import fa_dsv4_config_space, config_to_features


def load_calibration(cal_path: Path, arch):
    """把 910B 校准参数写入 arch; 没有校准文件时保持默认架构参数。"""
    if not cal_path.exists():
        return False
    data = json.loads(cal_path.read_text())
    full_params = data.get("full_params", {})
    for key, value in full_params.items():
        if hasattr(arch, key):
            setattr(arch, key, value)
    return True


def predict_space(arch, seq_list, heads, dim, accept_k):
    space = fa_dsv4_config_space(arch, dim=dim)
    if not space:
        raise RuntimeError("FA DS-V4 设计空间为空")

    out = {
        "arch": "Ascend910B",
        "shape": {"batch": 1, "heads": heads, "dim": dim},
        "design_space": space,
        "accept_k": accept_k,
        "per_seq_len": {},
    }

    model = NPUPerformanceModel(arch)
    for seq_len in seq_list:
        rows = []
        for cfg in space:
            feats = config_to_features(
                cfg,
                M=seq_len,
                N=seq_len,
                K=dim,
                kernel_type=NPUKernelType.FA,
                heads=heads,
                batch=1,
            )
            pred = model.predict_latency(feats)
            rows.append({
                "config": cfg,
                "pred_latency_ms": pred.total_latency_ns / 1e6,
                "pred_tile_latency_ms": pred.tile_latency_ns / 1e6,
                "issue_interval_ms": pred.issue_interval_ns / 1e6,
                "bottleneck": pred.bottleneck,
                "waves": pred.waves,
            })
        rows.sort(key=lambda row: row["pred_latency_ms"])
        out["per_seq_len"][str(seq_len)] = {
            "topk": rows[:accept_k],
            "full_ranking": rows,
        }
    return out


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--seq-list", type=int, nargs="+",
                        default=[256, 512, 1024, 2048, 4096, 8192, 16384])
    parser.add_argument("--heads", type=int, default=128)
    parser.add_argument("--dim", type=int, default=512)
    parser.add_argument("--accept-k", type=int, default=3)
    parser.add_argument("--cal", type=Path,
                        default=ROOT / "results" / "existing" /
                                "calibration_910b.json")
    parser.add_argument("--out", type=Path,
                        default=ROOT / "results" / "predictions" /
                                "fa_dsv4_topk.json")
    return parser.parse_args()


def main():
    args = parse_args()
    arch = create_ascend_910b_architecture()
    used_cal = load_calibration(args.cal, arch)
    result = predict_space(arch, args.seq_list, args.heads, args.dim,
                           args.accept_k)
    result["calibration"] = str(args.cal) if used_cal else "default"
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2, ensure_ascii=False))

    print(f"design_space: {len(result['design_space'])} configs")
    for seq_len, entry in result["per_seq_len"].items():
        print(f"\nseq_len={seq_len} top-{args.accept_k}:")
        for row in entry["topk"]:
            cfg = row["config"]
            print(f"  pred={row['pred_latency_ms']:.3f} ms  "
                  f"block_M={cfg['block_M']} block_N={cfg['block_N']} "
                  f"num_stages={cfg['fa_num_stages']}  "
                  f"bottleneck={row['bottleneck']}")
    print(f"\n-> {args.out}")


if __name__ == "__main__":
    main()
