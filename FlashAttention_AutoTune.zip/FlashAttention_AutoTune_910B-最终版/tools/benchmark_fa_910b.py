#!/usr/bin/env python3
"""Ascend 910B4 FlashAttention 自动调优基准脚本。

实验流程:
  1. 构建设计空间 (fa_dsv4_config_space)
  2. 用 NPUPerformanceModel 预测全部配置时延, 取 top-k
  3. 在 NPU 上编译并实测 top-k 配置
  4. 对每个 seq_len 选实测最快的优化内核
  5. 与朴素 FA 实现基线 (QK^T -> softmax -> P@V) 对比

必须在有 Ascend NPU 的宿主机执行, 例如:
  cd /root/FlashAttention_AutoTune_910B
  python3 tools/benchmark_fa_910b.py --accept-k 3

输出:
  results/benchmark/fa_dsv4_benchmark.jsonl   逐条记录
  results/benchmark/fa_dsv4_benchmark.json    汇总
  results/benchmark/fa_dsv4_benchmark.csv     汇总
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
KERNELS = ROOT / "src" / "kernels"
for path in (SRC, KERNELS):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--seq-list", type=int, nargs="+",
                        default=[256, 512, 1024, 2048, 4096, 8192, 16384])
    parser.add_argument("--heads", type=int, default=128)
    parser.add_argument("--dim", type=int, default=512)
    parser.add_argument("--accept-k", type=int, default=3,
                        help="性能模型 top-k 进入真机编译实测")
    parser.add_argument("--all", action="store_true",
                        help="忽略 top-k, 编译实测设计空间全部配置")
    parser.add_argument("--skip-naive", action="store_true",
                        help="跳过朴素 FA 实现基线")
    parser.add_argument("--naive-q-block", type=int, default=512)
    parser.add_argument("--naive-kv-block", type=int, default=2048)
    parser.add_argument("--warmup", type=int, default=1)
    parser.add_argument("--repeat", type=int, default=2)
    parser.add_argument("--out", type=Path,
                        default=ROOT / "results" / "benchmark" /
                                "fa_dsv4_benchmark")
    return parser.parse_args()


def load_topk_configs(seq_list, heads, dim, accept_k):
    from nputile import (NPUPerformanceModel, NPUKernelType,
                         create_ascend_910b_architecture)
    from nputile.kernel_configs import (fa_dsv4_config_space,
                                        config_to_features)

    arch = create_ascend_910b_architecture()
    space = fa_dsv4_config_space(arch, dim=dim)
    model = NPUPerformanceModel(arch)

    result = {}
    for seq_len in seq_list:
        rows = []
        for cfg in space:
            feats = config_to_features(
                cfg, M=seq_len, N=seq_len, K=dim,
                kernel_type=NPUKernelType.FA, heads=heads, batch=1)
            pred = model.predict_latency(feats)
            rows.append((pred.total_latency_ns / 1e6, cfg))
        rows.sort(key=lambda item: item[0])
        result[seq_len] = [cfg for _, cfg in rows[:accept_k]]
    return result, space


def baseline_naive(q, k, v, q_block=512, kv_block=2048):
    """朴素 FlashAttention 实现基线。

    直接按 QK^T -> online softmax -> P@V 计算。为避免长序列物化
    [B,H,S,S] 注意力矩阵导致 HBM 溢出, 采用分块 online-softmax 实现。
    """
    import torch

    batch, heads, seq_len, dim = q.shape
    scale = (1.0 / dim) ** 0.5
    outs = []
    for start in range(0, seq_len, q_block):
        stop = min(start + q_block, seq_len)
        qb = q[:, :, start:stop].float()
        acc = torch.zeros_like(qb)
        running_max = torch.full(
            (batch, heads, stop - start),
            float("-inf"), dtype=torch.float32, device=q.device)
        running_sum = torch.zeros(
            (batch, heads, stop - start),
            dtype=torch.float32, device=q.device)

        for kv_start in range(0, seq_len, kv_block):
            kv_stop = min(kv_start + kv_block, seq_len)
            kb = k[:, :, kv_start:kv_stop].float()
            vb = v[:, :, kv_start:kv_stop].float()
            scores = torch.matmul(qb, kb.transpose(-1, -2)) * scale
            new_max = torch.maximum(running_max, scores.amax(dim=-1))
            alpha = torch.exp(running_max - new_max)
            probs = torch.exp(scores - new_max.unsqueeze(-1))
            running_sum = running_sum * alpha + probs.sum(dim=-1)
            acc = acc * alpha.unsqueeze(-1) + torch.matmul(probs, vb)
            running_max = new_max

        outs.append((acc / running_sum.unsqueeze(-1)).to(torch.float16))
    return torch.cat(outs, dim=2)


def bench_latency(fn, warmup=5, repeat=10):
    from tilelang.profiler import do_bench
    return do_bench(fn, _n_warmup=warmup, _n_repeat=repeat,
                    return_mode="median")


def check_kernel(func, q, k, v, module):
    """与分块 fp32 参考比对, 返回 (max_abs_error, None/错误字符串)。"""
    import torch

    ref_fn = getattr(module, "ref_flash_attn", None)
    if ref_fn is None:
        return None, "no ref_flash_attn in kernel module"
    out = func(q, k, v)
    torch.npu.synchronize()
    ref = ref_fn(q, k, v)
    torch.npu.synchronize()
    try:
        torch.testing.assert_close(ref, out, rtol=2e-2, atol=2e-2)
        return float((ref - out).abs().max().item()), None
    except Exception as exc:  # noqa: BLE001
        return None, repr(exc)


def run_experiment(args):
    import torch
    import torch_npu
    import tilelang
    from tilelang.profiler import do_bench
    import flash_attn_tilelang_ds_v4 as fa_module

    torch.set_default_device("npu")
    torch.manual_seed(0)

    # 与已有 910B4 实测日志保持一致, 避免 kernel cache 影响复测
    if hasattr(tilelang, "disable_cache"):
        tilelang.disable_cache()

    selected, full_space = load_topk_configs(
        args.seq_list, args.heads, args.dim, args.accept_k)

    records = []
    summary = []
    for seq_len in args.seq_list:
        q = torch.randn((1, args.heads, seq_len, args.dim),
                        dtype=torch.float16)
        k = torch.randn((1, args.heads, seq_len, args.dim),
                        dtype=torch.float16)
        v = torch.randn((1, args.heads, seq_len, args.dim),
                        dtype=torch.float16)
        torch.npu.synchronize()

        naive_ms = None
        if not args.skip_naive:
            naive_ms = bench_latency(
                lambda: baseline_naive(q, k, v, args.naive_q_block,
                                       args.naive_kv_block),
                                     args.warmup, args.repeat)
            print(f"[baseline-naive] seq={seq_len}  {naive_ms:.4f} ms")

        configs = full_space if args.all else selected[seq_len]
        seq_records = []
        for cfg in configs:
            rec = {
                "seq_len": seq_len,
                "heads": args.heads,
                "dim": args.dim,
                "config": cfg,
                "source": "all" if args.all else f"model_top{args.accept_k}",
            }
            try:
                t0 = time.perf_counter()
                func = fa_module.flash_attention_fwd(
                    batch=1,
                    seq_len=seq_len,
                    heads_q=args.heads,
                    heads_kv=args.heads,
                    dim=args.dim,
                    block_M=cfg["block_M"],
                    block_N=cfg["block_N"],
                    num_stages=cfg["fa_num_stages"],
                )
                compile_ms = (time.perf_counter() - t0) * 1e3

                max_abs_error, check_error = check_kernel(
                    func, q, k, v, fa_module)
                tile_ms = bench_latency(lambda: func(q, k, v),
                                        args.warmup, args.repeat)
                rec.update({
                    "status": "ok",
                    "compile_ms": compile_ms,
                    "tilelang_ms": tile_ms,
                    "naive_ms": naive_ms,
                    "max_abs_error": max_abs_error,
                    "check_error": check_error,
                    "speedup_vs_naive": (naive_ms / tile_ms
                                         if naive_ms and tile_ms else None),
                })
                print(f"[tilelang] seq={seq_len} cfg={cfg}  "
                      f"compile={compile_ms:.0f} ms  "
                      f"run={tile_ms:.4f} ms")
            except Exception as exc:  # noqa: BLE001
                rec.update({"status": "error", "error": repr(exc)})
                print(f"[error] seq={seq_len} cfg={cfg}  {exc!r}")
            records.append(rec)
            seq_records.append(rec)

        ok_records = [r for r in seq_records if r.get("status") == "ok"]
        if ok_records:
            best = min(ok_records, key=lambda r: r["tilelang_ms"])
            summary.append({
                "seq_len": seq_len,
                "n_tested": len(seq_records),
                "best_config": best["config"],
                "best_tilelang_ms": best["tilelang_ms"],
                "naive_ms": naive_ms,
                "speedup_vs_naive": best.get("speedup_vs_naive"),
                "best_max_abs_error": best.get("max_abs_error"),
            })

    env = {
        "torch": torch.__version__,
        "torch_npu": getattr(torch_npu, "__version__", "unknown"),
        "tilelang": getattr(tilelang, "__version__", "unknown"),
        "cann_home": os.environ.get("ASCEND_TOOLKIT_LATEST_HOME", ""),
        "cann": os.environ.get("ASCEND_HOME_PATH", ""),
    }
    return {"records": records, "summary": summary,
            "environment": env,
            "design_space_n": len(full_space)}


def main():
    args = parse_args()
    import torch  # 确保 torch 已安装, 无 NPU 时会给出明确错误

    result = run_experiment(args)
    base = args.out
    base.parent.mkdir(parents=True, exist_ok=True)

    jsonl_path = base.with_suffix(".jsonl")
    with jsonl_path.open("w", encoding="utf-8") as f:
        for rec in result["records"]:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

    json_path = base.with_suffix(".json")
    json_path.write_text(json.dumps(result, indent=2, ensure_ascii=False))

    import csv
    csv_path = base.with_suffix(".csv")
    if result["summary"]:
        fields = ["seq_len", "n_tested", "best_config", "best_tilelang_ms",
                  "naive_ms", "speedup_vs_naive", "best_max_abs_error"]
        with csv_path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for row in result["summary"]:
                writer.writerow(row)

    print("\n===== SUMMARY =====")
    for row in result["summary"]:
        print(f"seq={row['seq_len']:>5}  best={row['best_tilelang_ms']:.4f} ms"
              f"  naive={row['naive_ms']:.4f} ms"
              f"  speedup_vs_naive={row['speedup_vs_naive']:.3f}")
    print(f"\n-> {jsonl_path}")
    print(f"-> {json_path}")
    print(f"-> {csv_path}")


if __name__ == "__main__":
    main()
