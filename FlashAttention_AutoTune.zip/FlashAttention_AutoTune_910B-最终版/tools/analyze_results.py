#!/usr/bin/env python3
"""把 benchmark JSONL 汇总为结题性能表。

用法:
  python3 tools/analyze_results.py
  python3 tools/analyze_results.py --jsonl results/benchmark/fa_dsv4_benchmark.jsonl

输出:
  results/benchmark/fa_dsv4_benchmark_report.md
"""
from __future__ import annotations

import argparse
import json
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def fmt(value, digits=4):
    return "N/A" if value is None else f"{value:.{digits}f}"


def build_report(rows, dst: Path):
    ok = [r for r in rows if r.get("status") == "ok" and
          (r.get("tilelang_ms") or r.get("latency_ms"))]
    if not ok:
        raise SystemExit("没有 ok 记录")

    by_seq = {}
    for r in ok:
        by_seq.setdefault(r.get("seq_len", r.get("M")), []).append(r)

    lines = []
    lines.append("# FlashAttention 910B4 性能测试报告（自动生成）")
    lines.append("")
    lines.append("> 本文件由 `tools/analyze_results.py` 从 benchmark JSONL 生成。")
    lines.append("")
    lines.append("## 汇总")
    lines.append("")
    lines.append("| seq_len | 实测配置数 | 本项目优化内核 (ms) | "
                 "朴素 FA 实现 (ms) | vs 朴素 FA 加速比 | max_abs_error |")
    lines.append("|---:|---:|---:|---:|---:|---:|")
    for seq_len, recs in sorted(by_seq.items()):
        best = min(recs, key=lambda r: r.get("tilelang_ms") or r.get("latency_ms"))
        best_ms = best.get("tilelang_ms") or best.get("latency_ms")
        naive_ms = best.get("naive_ms")
        speedup_naive = (naive_ms / best_ms
                         if naive_ms and best_ms else None)
        lines.append(
            f"| {seq_len} | {len(recs)} | {fmt(best_ms)} | "
            f"{fmt(naive_ms)} | "
            f"{fmt(speedup_naive, 3)}x | "
            f"{fmt(best.get('max_abs_error'), 6)} |"
        )

    speedups = []
    for recs in by_seq.values():
        best = min(recs, key=lambda r: r.get("tilelang_ms") or r.get("latency_ms"))
        best_ms = best.get("tilelang_ms") or best.get("latency_ms")
        if best.get("naive_ms") and best_ms:
            speedups.append(best["naive_ms"] / best_ms)
    if speedups:
        lines.append("")
        lines.append("**平均加速比 vs 朴素 FA 实现："
                     f"{statistics.mean(speedups):.3f}x**")
        lines.append("")
        lines.append(f"- 最小值：{min(speedups):.3f}x")
        lines.append(f"- 最大值：{max(speedups):.3f}x")
        lines.append(f"- 样本数：{len(speedups)}")
        lines.append("")

    lines.append("## 最优配置")
    lines.append("")
    for seq_len, recs in sorted(by_seq.items()):
        best = min(recs, key=lambda r: r.get("tilelang_ms") or r.get("latency_ms"))
        cfg = best["config"]
        lines.append(f"- seq_len={seq_len}: block_M={cfg.get('block_M')}, "
                     f"block_N={cfg.get('block_N')}, "
                     f"num_stages={cfg.get('fa_num_stages')}")
    lines.append("")
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text("\n".join(lines), encoding="utf-8")
    return dst


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--jsonl", type=Path,
                        default=ROOT / "results" / "benchmark" /
                                "fa_dsv4_benchmark.jsonl")
    parser.add_argument("--out", type=Path,
                        default=ROOT / "results" / "benchmark" /
                                "fa_dsv4_benchmark_report.md")
    args = parser.parse_args()
    rows = [json.loads(line) for line in args.jsonl.open()]
    dst = build_report(rows, args.out)
    print(f"-> {dst}")


if __name__ == "__main__":
    main()
