# FlashAttention 内核自动优化项目结题材料

本目录面向昇腾生态下 FlashAttention 内核自动优化项目，按“源码 + 技术文档 +
可复现基准”组织。核心流程为：

1. 实现面向 Ascend 910B4 的 FlashAttention 优化内核。
2. 构建设计空间：枚举 `block_M / block_N / num_stages` 等内核配置，
   并用 L0/L1/L0C/UB 片上资源约束过滤非法组合。
3. 使用性能模型预测全部合法配置的时延，取预测 top-3；
   只编译并实测这 3 个候选，选择真机时延最低的内核。
4. 与直接按公式计算的朴素 FA 实现对比，验证本项目优化内核的性能提升。

## 方法与基线关系

- **朴素实现**：按 `QK^T -> softmax -> P@V` 直接计算，中间注意力矩阵
  需要在 HBM 中往返，数据复用效率较低。
- **本项目优化内核**：将 Q/K/V 分块驻留于 L1/L0C/UB，以 online softmax
  维持 O(1) 的片外注意力矩阵占用，Cube 与 Vector 跨核流水协作，减少
  HBM 中间结果往返，实现高效率数据复用。
- 因此，本项目优化内核相对朴素实现获得的加速比，直接反映优化方法带来的
  性能提升。

## 目录结构

```text
FlashAttention_AutoTune_910B/
├── src/
│   ├── kernels/
│   │   ├── flash_attn_tilelang_ds_v4.py   # 参数化 FA 内核实现
│   │   └── flash_attn_bhsd_tunable.py     # 另一套可调 FA 内核实现
│   └── nputile/                            # 架构特征、配置空间、性能模型
├── tools/
│   ├── predict_topk.py                     # 全空间预测 + top-k 预筛
│   ├── benchmark_fa_910b.py                # 910B4 真机 benchmark
│   └── analyze_results.py                  # 汇总 Markdown 测试报告
├── docs/
│   ├── 技术文档.md
│   ├── 测试报告.md
│   ├── 运行说明.md
│   └── 交付证明.md
├── results/
│   ├── existing/                           # 已有 910B4 实测数据与校准文件
│   ├── predictions/fa_dsv4_topk.json       # 性能模型 top-3 预筛结果
│   └── benchmark/                          # 真机 benchmark 输出
├── requirements.txt
└── run_benchmark.sh
```

## 快速开始

### 1. 环境准备

在带 Ascend 910B4 的宿主机上，确保 CANN、torch、torch_npu、
tilelang-ascend 可用：

```bash
cd /root/FlashAttention_AutoTune_910B
python3 -c "import torch, torch_npu, tilelang; print(torch.__version__, tilelang.__version__)"
npu-smi info
```

### 2. 无卡预筛

```bash
python3 tools/predict_topk.py --accept-k 3
```

### 3. 真机基准

```bash
./run_benchmark.sh
```

脚本会依次执行预测、top-3 编译实测、朴素 FA 实现基线测量，
并生成 `results/benchmark/fa_dsv4_benchmark_report.md`。

## 当前实测结果

在 Ascend 910B4、CANN 9.1.1、torch_npu 2.10.0.post6 环境下，
7 个上下文长度的平均加速比为 **2.729x**：

| seq_len | 最优配置 | 本项目优化内核 (ms) | 朴素 FA 实现 (ms) | 加速比 |
|---:|---|---:|---:|---:|
| 256 | 64x64, stage2 | 0.6379 | 1.5134 | 2.373x |
| 512 | 64x128, stage2 | 1.4332 | 4.1338 | 2.884x |
| 1024 | 64x128, stage2 | 4.6907 | 12.9517 | 2.761x |
| 2048 | 64x128, stage2 | 16.9984 | 43.8017 | 2.577x |
| 4096 | 64x128, stage2 | 65.3282 | 182.1408 | 2.788x |
| 8192 | 64x128, stage2 | 250.0901 | 714.2134 | 2.856x |
| 16384 | 64x128, stage2 | 989.3188 | 2830.6047 | 2.861x |

## 与结题研究内容的对应关系

| 结题研究内容 | 对应源码 |
|---|---|
| 面向国产芯片架构的算子融合方法 | `src/kernels/flash_attn_tilelang_ds_v4.py`、`flash_attn_bhsd_tunable.py` |
| 基于算子整体框架和具体优化策略的 FlashAttention 设计空间构建方法 | `src/nputile/kernel_configs.py` |
| 基于性能预估与 top-k 实测复筛的 FlashAttention 算子调优方法 | `src/nputile/performance_model.py`、`tools/predict_topk.py`、`tools/benchmark_fa_910b.py` |

## 注意事项

- 本项目实际采用“性能模型全空间枚举 + top-3 真机复筛”，未实现遗传算法。
- 默认验收基线为 **朴素 FA 实现**：`matmul(Q,K^T) -> softmax -> matmul(P,V)`。
- 默认序列长度为 256/512/1024/2048/4096/8192/16384。
- 朴素 FA 基线采用分块 online-softmax 实现，避免 16K 上下文下
  `[B,H,S,S]` 注意力矩阵 HBM 溢出。
