#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

echo "==> 1/3 性能模型全空间预测 + top-3 预筛"
python3 tools/predict_topk.py --accept-k 3

echo "==> 2/3 910B4 真机编译/实测 + 朴素 FA 实现基线"
python3 tools/benchmark_fa_910b.py \
  --seq-list 256 512 1024 2048 4096 8192 16384 \
  --accept-k 3 \
  --warmup 1 \
  --repeat 2

echo "==> 3/3 汇总测试报告"
python3 tools/analyze_results.py

echo "完成。结果目录: results/"
