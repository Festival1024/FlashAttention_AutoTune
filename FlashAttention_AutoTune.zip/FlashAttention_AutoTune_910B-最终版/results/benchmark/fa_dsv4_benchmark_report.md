# FlashAttention 910B4 性能测试报告（自动生成）

> 本文件由 `tools/analyze_results.py` 从 benchmark JSONL 生成。

## 汇总

| seq_len | 实测配置数 | 本项目优化内核 (ms) | 朴素 FA 实现 (ms) | vs 朴素 FA 加速比 | max_abs_error |
|---:|---:|---:|---:|---:|---:|
| 256 | 3 | 0.6379 | 1.5134 | 2.373x | 0.000488 |
| 512 | 3 | 1.4332 | 4.1338 | 2.884x | 0.000488 |
| 1024 | 3 | 4.6907 | 12.9517 | 2.761x | 0.000244 |
| 2048 | 3 | 16.9984 | 43.8017 | 2.577x | 0.000122 |
| 4096 | 3 | 65.3282 | 182.1408 | 2.788x | 0.000122 |
| 8192 | 3 | 250.0901 | 714.2134 | 2.856x | 0.000061 |
| 16384 | 3 | 989.3188 | 2830.6047 | 2.861x | 0.000061 |

**平均加速比 vs 朴素 FA 实现：2.729x**

- 最小值：2.373x
- 最大值：2.884x
- 样本数：7

## 最优配置

- seq_len=256: block_M=64, block_N=64, num_stages=2
- seq_len=512: block_M=64, block_N=128, num_stages=2
- seq_len=1024: block_M=64, block_N=128, num_stages=2
- seq_len=2048: block_M=64, block_N=128, num_stages=2
- seq_len=4096: block_M=64, block_N=128, num_stages=2
- seq_len=8192: block_M=64, block_N=128, num_stages=2
- seq_len=16384: block_M=64, block_N=128, num_stages=2
