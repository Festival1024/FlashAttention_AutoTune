# 真机 benchmark 输出目录

在 Ascend 910B4 宿主机执行：

```bash
cd /root/FlashAttention_AutoTune_910B
./run_benchmark.sh
```

将生成：

```text
fa_dsv4_benchmark.jsonl
fa_dsv4_benchmark.json
fa_dsv4_benchmark.csv
fa_dsv4_benchmark_report.md
```

本目录中的文件为实际测试交付证明，执行前可保留为空。
